---
name: ha3d-floorplan-json
description: Generate or modify complete HA 3D floorplan JSON projects for import into the HA 3D editor, from text, floorplan images, or an exported project. Use when a user wants an importable layout JSON; do not use for generic 3D modeling formats.
metadata:
  short-description: Generate HA 3D import JSON
---

# HA 3D Floorplan JSON

Generate a complete `FloorplanProject` JSON that can be imported by HA 3D. Read `references/schema.md` before generating or changing data.

## Workflow

1. Decide whether this is a new project or a modification. For a new project, start from `assets/empty-project.json`; for a modification, preserve the input IDs and unrelated fields.
2. Collect or infer dimensions, floor count, room names and adjacency, doors/windows, furniture, and optional Home Assistant entity bindings. Ask for missing dimensions when they materially affect geometry; label unavoidable estimates.
3. Use metres for all dimensions. Wall and room coordinates are `[x, z]`; device positions are `[x, y, z]`; furniture positions are `[x, z]`; rotations are radians.
4. Generate only supported furniture kinds, device kinds, and model IDs listed in the reference. Use empty arrays when the user did not request devices or dashboard widgets.
5. Keep references valid: openings point to a wall in the same floor; furniture and devices point to an existing floor and, when present, room; materials and models must exist before they are referenced.
6. Return only valid JSON when the user requests the file. Do not wrap it in Markdown fences. If the user asks for an explanation, provide it separately from the JSON.
7. Choose an output mode: save a complete JSON file for manual import, or use `scripts/ha3d_api.py` when the user supplies a reachable HA 3D URL. For a new remote project use `create`; for an existing project use `update`.

## Geometry checks

Before returning JSON, check that every room polygon has at least three points, walls have non-zero length, openings fit on their wall, furniture is inside its room where a room is assigned, and IDs are unique. Avoid furniture overlap and preserve at least 0.8 m for requested circulation paths when possible.

For an existing project, do not rewrite embedded image data, HA `entityId` bindings, assets, or dashboard widgets unless explicitly asked. Make the smallest requested change.

## Validation

Run `scripts/validate_project.py <file.json>` when a local runtime is available. Report errors clearly and repair the JSON before delivering it. The application preview remains the final check for visual quality.

## Remote API mode

Configure the server once with `configure --url`; the saved URL is reused by later commands. `HA3D_URL` overrides it for one session. Use the API bridge only after the user has selected the target and reviewed the generated JSON. `update` requires an exported baseline and refuses to overwrite a project that changed since export. A write requires `--apply` and a new `--receipt` path. The server creates a backup before import.

```bash
python scripts/ha3d_api.py configure --url http://127.0.0.1:3000
python scripts/ha3d_api.py export --project-id demo-apartment --output current.json
python scripts/ha3d_api.py update --project-id demo-apartment --baseline current.json --file revised.json --apply --receipt update-receipt.json
python scripts/ha3d_api.py create --file new-home.json --apply --receipt create-receipt.json
```

Set `HA3D_AUTHORIZATION` when the deployment requires an `Authorization` header. If the AI client cannot reach the user's network, provide the validated JSON for manual import. Never claim a write succeeded without a successful response and an `imported` receipt.

