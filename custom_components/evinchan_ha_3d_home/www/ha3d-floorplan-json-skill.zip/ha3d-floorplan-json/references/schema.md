# HA 3D JSON schema guide

Root fields: `id`, `name`, `version`, `unit` (`m`), `createdAt`, `updatedAt`, `floors`, `assets`, `materials`, `dashboardWidgets`.

Each floor contains `id`, `name`, `level`, `height`, `walls`, `rooms`, `openings`, `devices`, and `furniture`.

- Wall: `start`/`end` are `[x,z]`, with `thickness`, `height`, and optional `materialId`.
- Room: `polygon` is a closed-area point list in `[x,z]` form; optional `floorMaterialId`, `ceilingMaterialId`, and HA `bindings`.
- Opening: `type` is `door` or `window`; `wallId` identifies its wall and `offset` is measured along that wall.
- Furniture: supported `kind` values include `sofa`, `bed`, `dining_table`, `desk`, `wardrobe`, `cabinet`, `tv_stand`, `kitchen_island`, `coffee_table`, `bookshelf`, `sideboard`, `shoe_cabinet`, `nightstand`, `side_table`, `wash_basin`, `toilet`, `water_heater`, `squat_toilet`, and `gas_stove`. Position is `[x,z]`.
- Device: position is `[x,y,z]`; `kind` is a supported Home Assistant device category and `entityId` should be a real HA entity when supplied.
- Material: `id`, `name`, `color`, optional `roughness` and `metalness`.

Do not invent model IDs. Preserve all existing IDs when modifying a project. `assets` may contain an image or model URL; do not duplicate large base64 data in an AI prompt unless explicitly needed.
