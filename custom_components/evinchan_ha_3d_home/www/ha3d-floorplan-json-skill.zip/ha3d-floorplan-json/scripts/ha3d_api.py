#!/usr/bin/env python3
"""HA 3D HTTP client. Python standard library only; no automatic write retries."""
import argparse
import json
import os
from pathlib import Path
import sys
import urllib.request
from urllib.parse import quote, urlsplit
from validate_project import main as validate

CONFIG_PATH = Path(os.environ.get('HA3D_CONFIG', Path.home() / '.ha3d' / 'config.json'))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def request(base, method, path, body=None):
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('HA3D_AUTHORIZATION'):
        headers['Authorization'] = os.environ['HA3D_AUTHORIZATION']
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base.rstrip('/') + path, data=data, method=method, headers=headers)
    with urllib.request.build_opener(NoRedirect).open(req, timeout=30) as response:
        return json.load(response)


def save(path, data):
    # Exclusive creation avoids losing an earlier export or recovery artifact.
    with open(path, 'x', encoding='utf-8') as output:
        json.dump(data, output, ensure_ascii=False, indent=2)

def configured_url():
    if os.environ.get('HA3D_URL'):
        return os.environ['HA3D_URL']
    try:
        return json.loads(CONFIG_PATH.read_text(encoding='utf-8')).get('url')
    except (OSError, ValueError):
        return None

def write_config(url):
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps({'url': url}, ensure_ascii=False, indent=2), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['configure', 'list', 'export', 'create', 'update'])
    parser.add_argument('--url', help='Server base URL; saved by configure and reusable via HA3D_URL')
    parser.add_argument('--project-id')
    parser.add_argument('--file', help='Complete generated project JSON')
    parser.add_argument('--output', help='New path for exported project')
    parser.add_argument('--baseline', help='Original exported project, required for update')
    parser.add_argument('--receipt', help='New path for write outcome/recovery information')
    parser.add_argument('--apply', action='store_true', help='Perform the already-authorized write')
    args = parser.parse_args()
    if args.mode == 'configure':
        if not args.url: parser.error('configure requires --url')
        parsed = urlsplit(args.url)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.username or parsed.query or parsed.fragment:
            parser.error('Use an http(s) application base URL without credentials, query or fragment')
        write_config(args.url.rstrip('/'))
        print(f'Saved HA 3D URL to {CONFIG_PATH}')
        return
    base = args.url or configured_url()
    if not base: parser.error('No server URL. Run configure --url http://host:port or set HA3D_URL')
    url = urlsplit(base)
    if url.scheme not in ('http', 'https') or not url.netloc or url.username or url.query or url.fragment:
        parser.error('Use an http(s) application base URL without credentials, query or fragment')
    def endpoint(project_id):
        return '/api/projects/' + quote(project_id, safe='')
    if args.mode == 'list':
        print(json.dumps(request(base, 'GET', '/api/projects'), ensure_ascii=False, indent=2))
        return
    if args.mode == 'export':
        if not args.project_id or not args.output:
            parser.error('export requires --project-id and --output')
        save(args.output, request(base, 'GET', endpoint(args.project_id) + '/export'))
        print('Exported to ' + args.output)
        return
    if not args.file:
        parser.error('create/update requires --file')
    errors = validate(args.file)
    if errors:
        raise ValueError('Validation failed: ' + '; '.join(errors))
    project = json.loads(Path(args.file).read_text(encoding='utf-8-sig'))
    target = args.project_id
    if args.mode == 'update':
        if not target or not args.baseline:
            parser.error('update requires --project-id and --baseline')
        baseline = json.loads(Path(args.baseline).read_text(encoding='utf-8-sig'))
        if baseline['id'] != target or project['id'] != target:
            raise ValueError('Project ID differs from selected target or baseline')
        current = request(base, 'GET', endpoint(target) + '/export')
        if current != baseline:
            raise ValueError('Remote project changed. Export again and reapply your changes.')
    if not args.apply:
        print(json.dumps({'status': 'validated-only', 'mode': args.mode, 'target': target,
                          'name': project['name']}, ensure_ascii=False))
        return
    if not args.receipt:
        parser.error('--apply requires --receipt (new file path)')
    save(args.receipt, {'status': 'pending', 'mode': args.mode, 'target': target})
    def record(status):
        Path(args.receipt).write_text(json.dumps({'status': status, 'mode': args.mode,
                                                'projectId': target}, ensure_ascii=False, indent=2), encoding='utf-8')
    try:
        if args.mode == 'create':
            target = request(base, 'POST', '/api/projects', {'name': project['name']})['project']['id']
            record('created-awaiting-import')
        result = request(base, 'POST', endpoint(target) + '/import', project)
        if result.get('project', {}).get('id') != target:
            raise ValueError('Unexpected project in response; inspect server state')
        record('imported')
        print(json.dumps({'status': 'imported', 'projectId': target}, ensure_ascii=False))
    except Exception:
        record('outcome-uncertain-inspect-server-before-retry')
        raise


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(f'Failed: {error}', file=sys.stderr)
        sys.exit(1)
