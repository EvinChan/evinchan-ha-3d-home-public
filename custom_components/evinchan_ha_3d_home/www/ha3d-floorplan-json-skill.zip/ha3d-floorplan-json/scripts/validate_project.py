#!/usr/bin/env python3
"""Lightweight structural validator for HA 3D FloorplanProject JSON."""
import json, math, sys

def main(path):
    data=json.load(open(path,encoding='utf-8-sig')); errors=[]; ids=set()
    def unique(value, where):
        if not isinstance(value,dict) or not isinstance(value.get('id'),str): errors.append(f'{where}: missing id'); return
        if value['id'] in ids: errors.append(f'{where}: duplicate id {value["id"]}')
        ids.add(value['id'])
    if not isinstance(data,dict): errors.append('root must be an object'); return errors
    if data.get('unit')!='m': errors.append('root.unit must be "m"')
    materials={m.get('id') for m in data.get('materials',[]) if isinstance(m,dict)}
    for mi,m in enumerate(data.get('materials',[])): unique(m,f'materials[{mi}]')
    for fi,f in enumerate(data.get('floors',[])):
        unique(f,f'floors[{fi}]'); floor_id=f.get('id'); wall_ids=set(); room_ids=set()
        for wi,w in enumerate(f.get('walls',[])):
            unique(w,f'floors[{fi}].walls[{wi}]'); wall_ids.add(w.get('id'))
            if not (isinstance(w.get('start'),list) and isinstance(w.get('end'),list) and len(w['start'])==2 and len(w['end'])==2): errors.append(f'wall {w.get("id")}: start/end must be [x,z]')
            elif w['start']==w['end']: errors.append(f'wall {w.get("id")}: zero length')
            if w.get('materialId') and w['materialId'] not in materials: errors.append(f'wall {w.get("id")}: unknown materialId')
        for ri,r in enumerate(f.get('rooms',[])):
            unique(r,f'floors[{fi}].rooms[{ri}]'); room_ids.add(r.get('id')); poly=r.get('polygon')
            if not isinstance(poly,list) or len(poly)<3: errors.append(f'room {r.get("id")}: polygon needs 3+ points')
            for key in ('floorMaterialId','ceilingMaterialId'):
                if r.get(key) and r[key] not in materials: errors.append(f'room {r.get("id")}: unknown {key}')
        for oi,o in enumerate(f.get('openings',[])):
            unique(o,f'floors[{fi}].openings[{oi}]')
            if o.get('wallId') not in wall_ids: errors.append(f'opening {o.get("id")}: unknown wallId')
        for section in ('devices','furniture'):
            for i,item in enumerate(f.get(section,[])):
                unique(item,f'floors[{fi}].{section}[{i}]')
                if item.get('floorId') != floor_id: errors.append(f'{section[:-1]} {item.get("id")}: floorId mismatch')
                if item.get('roomId') and item['roomId'] not in room_ids: errors.append(f'{item.get("id")}: unknown roomId')
    return errors

if __name__=='__main__':
    if len(sys.argv)!=2: print('usage: validate_project.py project.json'); sys.exit(2)
    errors=main(sys.argv[1])
    if errors:
        print('INVALID'); print('\n'.join(f'- {e}' for e in errors)); sys.exit(1)
    print('VALID: structural checks passed')
